async function fetchStats() {
    try {
        const response = await fetch('/api/stats', {
            headers: {
                'X-API-Key': 'super_secret_key_123'
            }
        });
        
        if (!response.ok) throw new Error('Failed to fetch');
        
        const data = await response.json();
        updateDashboard(data);
    } catch (error) {
        console.error('Error fetching stats:', error);
    }
}

function updateDashboard(data) {
    // Update DB Stats
    const stats = data.db_stats;
    document.getElementById('stat-pending').textContent = stats.PENDING || 0;
    document.getElementById('stat-running').textContent = stats.RUNNING || 0;
    document.getElementById('stat-completed').textContent = stats.COMPLETED || 0;
    document.getElementById('stat-failed').textContent = stats.FAILED || 0;
    document.getElementById('stat-dlq').textContent = stats.DLQ || 0;

    // Update Redis Stats
    const redis = data.redis_queues;
    document.getElementById('queue-ready').textContent = redis.ready || 0;
    document.getElementById('queue-scheduled').textContent = redis.scheduled || 0;
    document.getElementById('queue-dlq-redis').textContent = redis.dlq || 0;

    // Update Table
    const tbody = document.getElementById('tasks-tbody');
    tbody.innerHTML = '';
    
    data.recent_tasks.forEach(task => {
        const row = document.createElement('tr');
        
        // Format date
        const date = new Date(task.updated_at || task.created_at);
        const dateStr = date.toLocaleTimeString([], { hour12: false }) + '.' + String(date.getMilliseconds()).padStart(3, '0');

        row.innerHTML = `
            <td style="font-family: monospace; font-size: 0.9em; color: var(--text-secondary)">${task.id.substring(0, 8)}...</td>
            <td>${task.task_name}</td>
            <td><span class="status-badge status-${task.status}">${task.status}</span></td>
            <td>${task.retries}</td>
            <td style="color: var(--text-secondary); font-size: 0.9em">${dateStr}</td>
        `;
        tbody.appendChild(row);
    });
}

// Poll every 2 seconds
setInterval(fetchStats, 2000);
fetchStats(); // Initial fetch
